// SPDX-FileCopyrightText: 2023 Erin Catto
// SPDX-License-Identifier: MIT

#include "test_macros.h"

#include "box2d/collision.h"
#include "box2d/math_functions.h"

#include <float.h>

static b2Capsule capsule = { { -1.0f, 0.0f }, { 1.0f, 0.0f }, 1.0f };
static b2Circle circle = { { 1.0f, 0.0f }, 1.0f };
static b2Polygon box;
static b2Segment segment = { { 0.0f, 1.0f }, { 0.0f, -1.0f } };

#define N 4

static int ShapeMassTest( void )
{
	{
		b2MassData md = b2ComputeCircleMass( &circle, 1.0f );
		ENSURE_SMALL( md.mass - B2_PI, FLT_EPSILON );
		ENSURE( md.center.x == 1.0f && md.center.y == 0.0f );
		ENSURE_SMALL( md.rotationalInertia - 0.5f * B2_PI, FLT_EPSILON );
	}

	{
		float radius = capsule.radius;
		float length = b2Distance( capsule.center1, capsule.center2 );

		b2MassData md = b2ComputeCapsuleMass( &capsule, 1.0f );

		// Box that full contains capsule
		b2Polygon r = b2MakeBox( radius + 0.5f * length, radius );
		b2MassData mdUpper = b2ComputePolygonMass( &r, 1.0f );

		// Approximate capsule using convex hull
		b2Vec2 points[2 * N];
		float d = B2_PI / ( N - 1.0f );
		float angle = -0.5f * B2_PI;
		for ( int i = 0; i < N; ++i )
		{
			points[i].x = 1.0f + radius * cosf( angle );
			points[i].y = radius * sinf( angle );
			angle += d;
		}

		angle = 0.5f * B2_PI;
		for ( int i = N; i < 2 * N; ++i )
		{
			points[i].x = -1.0f + radius * cosf( angle );
			points[i].y = radius * sinf( angle );
			angle += d;
		}

		b2Hull hull = b2ComputeHull( points, 2 * N );
		b2Polygon ac = b2MakePolygon( &hull, 0.0f );
		b2MassData mdLower = b2ComputePolygonMass( &ac, 1.0f );

		ENSURE( mdLower.mass < md.mass && md.mass < mdUpper.mass );
		ENSURE( mdLower.rotationalInertia < md.rotationalInertia && md.rotationalInertia < mdUpper.rotationalInertia );
	}

	{
		b2MassData md = b2ComputePolygonMass( &box, 1.0f );
		ENSURE_SMALL( md.mass - 4.0f, FLT_EPSILON );
		ENSURE_SMALL( md.center.x, FLT_EPSILON );
		ENSURE_SMALL( md.center.y, FLT_EPSILON );
		ENSURE_SMALL( md.rotationalInertia - 8.0f / 3.0f, 2.0f * FLT_EPSILON );
	}

	{
		b2Vec2 offset = {0.4f, -0.7f};
		b2Polygon b1 = b2MakeBox( 0.25f, 0.5f );
		b2Polygon b2 = b2MakeOffsetBox( 0.25f, 0.5f, offset, b2Rot_identity );

		b2MassData m1 = b2ComputePolygonMass( &b1, 1.0f );
		b2MassData m2 = b2ComputePolygonMass( &b2, 1.0f );
		
		ENSURE_SMALL( m1.mass - m2.mass, FLT_EPSILON );
		ENSURE_SMALL( m1.rotationalInertia - m2.rotationalInertia, FLT_EPSILON );
		ENSURE_SMALL( m2.center.x - offset.x, FLT_EPSILON );
		ENSURE_SMALL( m2.center.y - offset.y, FLT_EPSILON );
	}

	return 0;
}

static int ShapeAABBTest( void )
{
	{
		b2AABB b = b2ComputeCircleAABB( &circle, b2WorldTransform_identity );
		ENSURE_SMALL( b.lowerBound.x, FLT_EPSILON );
		ENSURE_SMALL( b.lowerBound.y + 1.0f, FLT_EPSILON );
		ENSURE_SMALL( b.upperBound.x - 2.0f, FLT_EPSILON );
		ENSURE_SMALL( b.upperBound.y - 1.0f, FLT_EPSILON );
	}

	{
		b2AABB b = b2ComputePolygonAABB( &box, b2WorldTransform_identity );
		ENSURE_SMALL( b.lowerBound.x + 1.0f, FLT_EPSILON );
		ENSURE_SMALL( b.lowerBound.y + 1.0f, FLT_EPSILON );
		ENSURE_SMALL( b.upperBound.x - 1.0f, FLT_EPSILON );
		ENSURE_SMALL( b.upperBound.y - 1.0f, FLT_EPSILON );
	}

	{
		b2AABB b = b2ComputeSegmentAABB( &segment, b2WorldTransform_identity );
		ENSURE_SMALL( b.lowerBound.x, FLT_EPSILON );
		ENSURE_SMALL( b.lowerBound.y + 1.0f, FLT_EPSILON );
		ENSURE_SMALL( b.upperBound.x, FLT_EPSILON );
		ENSURE_SMALL( b.upperBound.y - 1.0f, FLT_EPSILON );
	}

	return 0;
}

static int PointInShapeTest( void )
{
	b2Vec2 p1 = { 0.5f, 0.5f };
	b2Vec2 p2 = { 4.0f, -4.0f };

	{
		bool hit;
		hit = b2PointInCircle(&circle,  p1 );
		ENSURE( hit == true );
		hit = b2PointInCircle( &circle, p2 );
		ENSURE( hit == false );
	}

	{
		bool hit;
		hit = b2PointInPolygon( &box,  p1);
		ENSURE( hit == true );
		hit = b2PointInPolygon(&box,  p2);
		ENSURE( hit == false );
	}

	return 0;
}

static int RayCastShapeTest( void )
{
	b2RayCastInput input = { { -4.0f, 0.0f }, { 8.0f, 0.0f }, 1.0f };

	{
		b2CastOutput output = b2RayCastCircle( &circle, & input );
		ENSURE( output.hit );
		ENSURE_SMALL( output.normal.x + 1.0f, FLT_EPSILON );
		ENSURE_SMALL( output.normal.y, FLT_EPSILON );
		ENSURE_SMALL( output.fraction - 0.5f, FLT_EPSILON );
	}

	{
		b2CastOutput output = b2RayCastPolygon( &box, & input);
		ENSURE( output.hit );
		ENSURE_SMALL( output.normal.x + 1.0f, FLT_EPSILON );
		ENSURE_SMALL( output.normal.y, FLT_EPSILON );
		ENSURE_SMALL( output.fraction - 3.0f / 8.0f, FLT_EPSILON );
	}

	{
		b2CastOutput output = b2RayCastSegment( &segment, &input, true );
		ENSURE( output.hit );
		ENSURE_SMALL( output.normal.x + 1.0f, FLT_EPSILON );
		ENSURE_SMALL( output.normal.y, FLT_EPSILON );
		ENSURE_SMALL( output.fraction - 0.5f, FLT_EPSILON );
	}

	return 0;
}

int ShapeTest( void )
{
	box = b2MakeBox( 1.0f, 1.0f );

	RUN_SUBTEST( ShapeMassTest );
	RUN_SUBTEST( ShapeAABBTest );
	RUN_SUBTEST( PointInShapeTest );
	RUN_SUBTEST( RayCastShapeTest );

	return 0;
}
